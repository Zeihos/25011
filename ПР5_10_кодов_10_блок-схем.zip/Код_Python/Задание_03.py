n = int(input("Введите N: "))
result = 0

for i in range(1, n + 1):
    result += i

print("Сумма чисел:", result)
