positive = 0
negative = 0
zeros = 0
total = 0

for i in range(10):
    number = int(input(f'Введите число {i + 1}: '))
    total += number

    if number > 0:
        positive += 1
    elif number < 0:
        negative += 1
    else:
        zeros += 1

print('Положительных:', positive)
print('Отрицательных:', negative)
print('Нулей:', zeros)
print('Сумма всех чисел:', total)
