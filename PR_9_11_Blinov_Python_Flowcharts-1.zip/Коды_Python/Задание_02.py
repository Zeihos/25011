# Задание 2. Обратный отсчёт от 10 до 1 и команда «Старт!».
number = 10

while number >= 1:
    print(number)
    number -= 1

print('Старт!')
