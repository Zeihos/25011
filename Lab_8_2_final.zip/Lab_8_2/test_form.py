from pages import FormPage


def test_submit_form(browser):
    page = FormPage(browser)
    page.open()
    page.fill_text("Тестовое значение")
    page.submit()
    result = page.get_message_text()
    assert result == "Received!", f"Ожидалось 'Received!', получено '{result}'"
