from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class FormPage:
    def __init__(self, driver):
        self.driver = driver
        self.url = "https://www.selenium.dev/selenium/web/web-form.html"
        self.text_input = (By.NAME, "my-text")
        self.submit_button = (By.CSS_SELECTOR, "button")
        self.message = (By.ID, "message")

    def open(self):
        self.driver.get(self.url)

    def fill_text(self, text):
        element = self.driver.find_element(*self.text_input)
        element.clear()
        element.send_keys(text)

    def submit(self):
        self.driver.find_element(*self.submit_button).click()

    def get_message_text(self):
        wait = WebDriverWait(self.driver, 5)
        element = wait.until(EC.visibility_of_element_located(self.message))
        return element.text
