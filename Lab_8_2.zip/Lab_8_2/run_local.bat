@echo off
setlocal
set "LAB_LOCAL_FORM=1"
call "%~dp0run.bat"
exit /b %ERRORLEVEL%
