from pages import SearchPage


def test_search(browser, screenshot):
    # Вариант Б: поиск
    page = SearchPage(browser)
    page.open()
    query = 'Python'
    page.search(query)
    results = page.get_results()
    assert any(query.lower() in title.lower() for title in results), results
    screenshot()
