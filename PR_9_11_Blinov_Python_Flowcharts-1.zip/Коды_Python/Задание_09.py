# Задание 9. Вклад 10 000 рублей под 5% годовых на 5 лет.
amount = 10000

for year in range(5):
    amount *= 1.05

print(f'Сумма через 5 лет: {amount:.2f} руб.')
