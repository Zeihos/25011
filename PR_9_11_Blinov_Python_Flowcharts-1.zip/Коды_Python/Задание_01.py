# Задание 1. Вывести числа от 1 до 10 с помощью цикла for.
for number in range(1, 11):
    print(number)
