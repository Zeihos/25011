# Задание 10. Первые 10 чисел последовательности Фибоначчи.
a = 0
b = 1

for i in range(10):
    print(a, end=' ')
    a, b = b, a + b

print()
