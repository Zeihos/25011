from pages import LoginPage


def test_invalid_password(browser, screenshot):
    # Вариант А: неверный пароль
    page = LoginPage(browser)
    page.open()
    page.fill_credentials('student', 'wrong123')
    page.submit()
    result = page.get_error()
    assert 'неверный пароль' in result.lower(), result
    screenshot()
