# Задание 6. Угадать число 15 с подсказками.
secret = 15

while True:
    number = int(input('Введите число: '))
    if number < secret:
        print('Загаданное число больше')
    elif number > secret:
        print('Загаданное число меньше')
    else:
        print('Поздравляем! Вы угадали!')
        break
