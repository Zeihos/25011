import os
from pathlib import Path

from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


SITE = Path(__file__).resolve().parent / 'site'


class FormPage:
    def __init__(self, driver):
        self.driver = driver
        self.url = 'https://www.selenium.dev/selenium/web/web-form.html'
        # Локальная копия сценария для демонстрации без доступа к сайту.
        if os.getenv('LAB_LOCAL_FORM') == '1':
            self.url = (SITE / 'web-form.html').as_uri()
        self.text_input = (By.NAME, 'my-text')
        self.submit_button = (By.CSS_SELECTOR, 'button')
        self.message = (By.ID, 'message')

    def open(self):
        self.driver.get(self.url)

    def fill_text(self, text):
        element = self.driver.find_element(*self.text_input)
        element.clear()
        element.send_keys(text)

    def submit(self):
        self.driver.find_element(*self.submit_button).click()

    def get_message_text(self):
        wait = WebDriverWait(self.driver, 5)
        element = wait.until(EC.visibility_of_element_located(self.message))
        return element.text


class LoginPage:
    def __init__(self, driver):
        self.driver = driver
        self.url = (SITE / 'login.html').as_uri()
        self.login = (By.ID, 'login')
        self.password = (By.ID, 'password')
        self.button = (By.ID, 'login-button')
        self.error = (By.ID, 'error')

    def open(self):
        self.driver.get(self.url)

    def fill_credentials(self, login, password):
        for locator, value in ((self.login, login), (self.password, password)):
            element = self.driver.find_element(*locator)
            element.clear()
            element.send_keys(value)

    def submit(self):
        self.driver.find_element(*self.button).click()

    def get_error(self):
        wait = WebDriverWait(self.driver, 5)
        return wait.until(EC.visibility_of_element_located(self.error)).text


class SearchPage:
    def __init__(self, driver):
        self.driver = driver
        self.url = (SITE / 'index.html').as_uri()
        self.search_input = (By.NAME, 'query')
        self.results = (By.CSS_SELECTOR, '.result-title')

    def open(self):
        self.driver.get(self.url)

    def search(self, query):
        element = self.driver.find_element(*self.search_input)
        element.clear()
        element.send_keys(query, Keys.ENTER)

    def get_results(self):
        elements = WebDriverWait(self.driver, 5).until(
            EC.visibility_of_all_elements_located(self.results)
        )
        return [element.text for element in elements]


class NavigationPage:
    def __init__(self, driver):
        self.driver = driver
        self.url = (SITE / 'index.html').as_uri()
        self.about_link = (By.LINK_TEXT, 'О компании')
        self.heading = (By.TAG_NAME, 'h1')

    def open(self):
        self.driver.get(self.url)

    def open_about(self):
        self.driver.find_element(*self.about_link).click()
        WebDriverWait(self.driver, 5).until(EC.title_contains('О компании'))

    def get_heading(self):
        return self.driver.find_element(*self.heading).text
