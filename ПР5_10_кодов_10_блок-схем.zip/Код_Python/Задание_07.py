n = int(input("Введите натуральное число N: "))
factorial = 1

for i in range(1, n + 1):
    factorial *= i

print("Факториал:", factorial)
