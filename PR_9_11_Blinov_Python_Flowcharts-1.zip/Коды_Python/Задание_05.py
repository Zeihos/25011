# Задание 5. Вывести чётные числа от 1 до 50 и их количество.
count = 0

for number in range(1, 51):
    if number % 2 == 0:
        print(number)
        count += 1

print('Количество чётных чисел:', count)
