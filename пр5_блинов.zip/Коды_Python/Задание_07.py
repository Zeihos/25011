n = int(input('Введите натуральное число N: '))
factorial = 1

for number in range(1, n + 1):
    factorial *= number

print('Факториал числа:', factorial)
