from pages import NavigationPage


def test_navigation(browser, screenshot):
    # Вариант В: переход по ссылке
    page = NavigationPage(browser)
    page.open()
    page.open_about()
    assert 'О компании' in browser.title, browser.title
    assert page.get_heading() == 'О компании'
    screenshot()
