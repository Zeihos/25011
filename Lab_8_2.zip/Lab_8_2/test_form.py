from pages import FormPage


def test_submit_form(browser, screenshot):
    # Arrange — подготовка
    page = FormPage(browser)
    page.open()
    # Act — действие
    page.fill_text('Тестовое значение')
    page.submit()
    # Assert — проверка
    result = page.get_message_text()
    assert result == 'Received!', f"Ожидалось 'Received!', получено '{result}'"
    screenshot()
