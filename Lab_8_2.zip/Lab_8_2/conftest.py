import os
from pathlib import Path

import pytest
from selenium import webdriver
from selenium.webdriver.chrome.options import Options


@pytest.fixture
def browser():
    options = Options()
    if os.getenv('LAB_HEADLESS') == '1':
        options.add_argument('--headless=new')
    driver = webdriver.Chrome(options=options)
    try:
        driver.maximize_window()
        yield driver
    finally:
        driver.quit()


@pytest.fixture
def screenshot(browser, request):
    def save():
        folder = Path(__file__).resolve().parent / 'screenshots'
        folder.mkdir(exist_ok=True)
        path = folder / f'{request.node.name}.png'
        assert browser.save_screenshot(str(path)), 'Не удалось сохранить снимок'
    return save
