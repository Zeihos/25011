from pathlib import Path
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class LoginPage:
    def __init__(self, driver):
        self.driver = driver
        self.url = (Path(__file__).resolve().parent / "login.html").as_uri()
        self.login = (By.ID, "login")
        self.password = (By.ID, "password")
        self.button = (By.ID, "login-button")
        self.error = (By.CLASS_NAME, "error")

    def open(self):
        self.driver.get(self.url)

    def fill_credentials(self, login, password):
        for locator, value in ((self.login, login), (self.password, password)):
            element = self.driver.find_element(*locator)
            element.clear()
            element.send_keys(value)

    def submit(self):
        self.driver.find_element(*self.button).click()

    def get_error(self):
        wait = WebDriverWait(self.driver, 5)
        return wait.until(EC.visibility_of_element_located(self.error)).text


def test_invalid_password(browser):
    page = LoginPage(browser)
    page.open()
    page.fill_credentials("student", "wrong123")
    page.submit()
    assert "неверный пароль" in page.get_error().lower()
