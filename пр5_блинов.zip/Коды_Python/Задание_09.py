amount = 10000

for year in range(5):
    amount *= 1.05

print(f'Сумма через 5 лет: {amount:.2f} руб.')
