amount = 10000.0

for year in range(5):
    amount *= 1.05

print(f"Сумма вклада через 5 лет: {amount:.2f} руб.")
