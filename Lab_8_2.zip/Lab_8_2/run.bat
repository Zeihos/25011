@echo off
cd /d "%~dp0"
set "PY=py"
where py >nul 2>&1
if errorlevel 1 set "PY=python"
%PY% -m pip install -r requirements.txt
if errorlevel 1 goto failed
%PY% -m pytest -v --html=report.html --self-contained-html
set "RESULT=%ERRORLEVEL%"
if exist report.html start "" "%~dp0report.html"
echo Pytest exit code: %RESULT%
pause
exit /b %RESULT%
:failed
echo Dependency installation failed. Check Python and Internet connection.
pause
exit /b 1
