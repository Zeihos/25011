# Задание 4. Таблица умножения введённого числа на 1–10.
number = int(input('Введите число: '))

for i in range(1, 11):
    print(f'{number} × {i} = {number * i}')
