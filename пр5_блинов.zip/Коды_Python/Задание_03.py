n = int(input('Введите N: '))
total = 0

for number in range(1, n + 1):
    total += number

print('Сумма чисел:', total)
